#!/bin/bash

tar -cvzf cse490h-wgzs.tar 490h-wgzs-read-only/proj/*.java 490h-wgzs-read-only/simulator_scripts/* 490h-wgzs-read-only/writeups/project*/writeup.pdf 490h-wgzs-read-only/output/*/* 490h-wgzs-read-only/writeups/project*/writeup.tex 490h-wgzs-read-only/writeups/project*/*.png 490h-wgzs-read-only/synoptic_args/* 490h-wgzs-read-only/*.sh 490h-wgzs-read-only/jars/* 490h-wgzs-read-only/jars/lib/* 490h-wgzs-read-only/*.pl
