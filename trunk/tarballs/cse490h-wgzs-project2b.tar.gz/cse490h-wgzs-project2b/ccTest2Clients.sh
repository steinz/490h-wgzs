#!/bin/bash

./execute.pl -s -n CacheCoherenceTester -f 0 -c simulator_scripts/CacheCoherenceTester2Clients
