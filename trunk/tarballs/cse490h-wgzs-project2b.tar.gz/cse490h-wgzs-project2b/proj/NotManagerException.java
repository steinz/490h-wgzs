/**
 * CSE 490h
 * @author wayger, steinz
 */

public class NotManagerException extends Exception {

	public NotManagerException(String string) {
		super(string);
	}

	public NotManagerException() {
		super();
	}

	private static final long serialVersionUID = -2133442099641600446L;

}
