/**
 * CSE 490h
 * @author wayger, steinz
 */

public class NotClientException extends Exception {

	private static final long serialVersionUID = 2823129727550319441L;

}
