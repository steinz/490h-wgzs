/**
 * CSE 490h
 * @author wayger, steinz
 */

public class PacketPackException extends Exception {

	private static final long serialVersionUID = 5273893683486775453L;

	public PacketPackException(String msg) {
		super(msg);
	}
	
}
