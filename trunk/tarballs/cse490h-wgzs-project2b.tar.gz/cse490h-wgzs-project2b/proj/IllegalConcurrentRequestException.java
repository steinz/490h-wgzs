/**
 * CSE 490h
 * @author wayger, steinz
 */

public class IllegalConcurrentRequestException extends Exception {

	private static final long serialVersionUID = 2071631296141888061L;

}
