/**
 * CSE 490h
 * @author wayger, steinz
 */

public class MissingPendingRequestException extends Exception {

	private static final long serialVersionUID = -2553306180790311198L;

	public MissingPendingRequestException(String string) {
		super(string);
	}
	
}
