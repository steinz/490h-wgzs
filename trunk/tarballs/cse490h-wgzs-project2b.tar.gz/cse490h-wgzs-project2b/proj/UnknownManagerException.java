/**
 * CSE 490h
 * @author wayger, steinz
 */

public class UnknownManagerException extends Exception {

	private static final long serialVersionUID = 6525390876463186997L;

}
