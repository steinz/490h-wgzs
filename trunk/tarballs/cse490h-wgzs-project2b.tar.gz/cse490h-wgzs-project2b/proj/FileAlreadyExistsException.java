/**
 * CSE 490h
 * @author wayger, steinz
 */

import java.io.IOException;

public class FileAlreadyExistsException extends IOException {

	private static final long serialVersionUID = -4672741364887472499L;

}
